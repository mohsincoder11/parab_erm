<?php

namespace App\Models\bank_master;

use Illuminate\Database\Eloquent\Model;

class Bank extends Model
{
    //
}
