<?php

namespace App\Models\employee_master\other_master;

use Illuminate\Database\Eloquent\Model;

class ArrangementMethodModel extends Model
{
    protected $table='arrangement_method';
    protected $fillable=['arrangement_method'];
}
