<?php

namespace App\Models\employee_master\other_master;

use Illuminate\Database\Eloquent\Model;

class JobCategoryModel extends Model
{
    protected $table = 'job_category';
    protected $fillable = ['job_category'];
}
