<?php

namespace App\Models\employee_master\other_master\qualification;

use Illuminate\Database\Eloquent\Model;

class EducationLevelModel extends Model
{
    protected $table='education_level';
    protected $fillable=['education_level'];
}
