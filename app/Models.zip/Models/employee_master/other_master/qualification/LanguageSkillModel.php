<?php

namespace App\Models\employee_master\other_master\qualification;

use Illuminate\Database\Eloquent\Model;

class LanguageSkillModel extends Model
{
    protected $table='language_skill';
    protected $fillable=['language_skill'];
}
